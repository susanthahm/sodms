-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 31, 2021 at 01:37 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `odms`
--

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `customer_name` varchar(128) NOT NULL,
  `delivery_address` text NOT NULL,
  `contact_no` varchar(24) NOT NULL,
  `product_id` smallint(6) NOT NULL,
  `qty` smallint(6) NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `delivery_charge` decimal(10,2) NOT NULL,
  `payment_type` varchar(4) NOT NULL,
  `delivery_by` varchar(16) NOT NULL,
  `delivery_date` date DEFAULT NULL,
  `created_by` varchar(16) NOT NULL,
  `edited_by` varchar(16) NOT NULL,
  `order_status` varchar(3) NOT NULL DEFAULT 'NEW' COMMENT 'NEW, PND, COM, RTN',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `orders`
--


-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `status` char(1) NOT NULL DEFAULT 'A',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `products`
--


-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `username` varchar(16) NOT NULL,
  `password` varchar(32) NOT NULL,
  `privileges` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `privileges`) VALUES
(1, 'admin', '9e121dafcf756ffe8f7c60fa839d7888', 'create_orders,edit_orders,complete_orders,return_orders,delete_orders,manage_products,manage_users'),
(3, 'ranga', 'e504b1ff2be67e31b5aced5a1415ef48', 'create_orders,edit_orders,complete_orders,return_orders,delete_orders,manage_products,manage_users');
